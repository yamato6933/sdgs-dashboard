"use client";

export default function GridPage() {
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">SDGs Data Grid</h1>
      <p className="text-gray-600">
        This page will display SDGs data in a grid format.
      </p>
    </div>
  );
}
